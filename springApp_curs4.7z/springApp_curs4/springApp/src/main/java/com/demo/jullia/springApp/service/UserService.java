package com.demo.jullia.springApp.service;

import com.demo.jullia.springApp.database.User;
import com.demo.jullia.springApp.database.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    UserDAO userDAO;

    public boolean register(String email, String password, String password2) {
        if (!password.equals(password2)) {
            return false;
        } else {
            userDAO.save(email, password);
        }
        return true;
    }

    public boolean login(String email, String password) {
        List<User> userList = userDAO.findByEmail(email);

        if (userList.size() == 0 || userList.size() > 1) {
            return false;
        }
        if (userList.size() == 1) {
            User user = userList.get(0);
            if (!user.getPassword().equals(password)) {
                return false;
            } else {
                return true;
            }
        }
        return true;
    }
}