package com.demo.jullia.springApp.controller;

import com.demo.jullia.springApp.database.User;
import com.demo.jullia.springApp.database.UserRowMapper;
import com.demo.jullia.springApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    UserService userService;
    @GetMapping("/register-form")
    public ModelAndView registerAction(@RequestParam("email") String email,
                                       @RequestParam("password") String password,
                                       @RequestParam("password-again") String password2){
        ModelAndView modelAndView = new ModelAndView("register");

        if(!userService.register(email, password, password2)){
            modelAndView.addObject("message", "Parolele nu corespund");
            return  modelAndView;
        }
        return new ModelAndView("redirect:index.html");
    }
    @GetMapping("/register")
    public ModelAndView register(){
        return new ModelAndView("register");

    }

    @GetMapping("/login")
    public ModelAndView login(@RequestParam("email") String email,
                              @RequestParam("password") String password,
                              HttpServletRequest httpServletRequest) {
        ModelAndView modelAndView = new ModelAndView("index");
        if(!userService.login(email, password)){
            modelAndView.addObject("message", "Credentialele nu sunt bune");
        }
        else {
            httpServletRequest.getSession().setAttribute("logged", true);
            return new ModelAndView("redirect:/dashboard");
        }
        return modelAndView;
    }

    @GetMapping("dashboard")
    public ModelAndView dashboard(HttpServletRequest httpServletRequest){
        //cum verific daca user-ul este logat sau nu?
        HttpSession httpSession = httpServletRequest.getSession();
        Object object = httpSession.getAttribute("logged");
        boolean logged;
        if(object==null){
            logged=false;
        }else{
            logged=(Boolean) object;
        }
        if(logged){
            return  new ModelAndView("dashboard");
        }else{
            return new ModelAndView("index");
        }


    }
}