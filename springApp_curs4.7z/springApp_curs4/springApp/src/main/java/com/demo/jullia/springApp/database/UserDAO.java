package com.demo.jullia.springApp.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UserDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public  void save(String email, String password){
        User user=new User();
        user.setEmail(email);
        user.setPassword(password);

        entityManager.persist(user);

    }

    public  List<User> findByEmail(String email){
        Query query=entityManager.createNativeQuery("select * from users where email='" + email+"'", User.class);
        return query.getResultList();
    }
}
