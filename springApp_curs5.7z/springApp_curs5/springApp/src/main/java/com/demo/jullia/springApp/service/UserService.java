package com.demo.jullia.springApp.service;

import com.demo.jullia.springApp.dao.User;
import com.demo.jullia.springApp.dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    UserDAO userDao;

    public void save(String email, String password){
        User user=new User();
        user.setEmail(email);
        user.setPassword(password);
        userDao.save(user);
    }

    public List<User> getUsersByEmail(String email){
        return userDao.findByEmail(email);
    }
}
