package ro.link.orm1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Orm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
