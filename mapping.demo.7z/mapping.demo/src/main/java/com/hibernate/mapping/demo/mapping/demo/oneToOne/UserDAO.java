package com.hibernate.mapping.demo.mapping.demo.oneToOne;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class UserDAO {

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public  User save(User user){
//        entityManager.persist(user.getAddress());
        entityManager.persist(user);
        return  user;
    }
    public List<User> findAll(){
        Query query= entityManager.createNativeQuery("select * from user", User.class);
        return query.getResultList();
    }

}
