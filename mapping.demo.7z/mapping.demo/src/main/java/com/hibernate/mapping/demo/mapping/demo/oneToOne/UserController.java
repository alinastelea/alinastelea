package com.hibernate.mapping.demo.mapping.demo.oneToOne;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller

public class UserController {

    @Autowired
    UserDAO userDAO;

    @GetMapping("/listUsers")
    @ResponseBody
    public List<User> listUser(){
        return  userDAO.findAll();
    }
    @GetMapping("/dummyUser")
    @ResponseBody
    public User addDummyUser(){
        User user=new User();
        user.setUsername("test123");

        Address address=new Address();
        address.setAddress("Strada cu flori");

        user.setAddress(address);
        userDAO.save(user);
        return user;
    }
}
